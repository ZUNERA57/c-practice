#include<iostream>
using namespace std;
void printMultiplicationTable(int num){
	cout<<"Multiplication table of "<<num<<":\n";
	for(int i=1;i<=10;i++){
		cout<<num<<"*"<<i<<"="<<num* i<<endl;
	}
}
int main(){
	int num = 7;
	printMultiplicationTable(num);
}
