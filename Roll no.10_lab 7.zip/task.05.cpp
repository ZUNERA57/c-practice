#include<iostream>
using namespace std;
void printWelcome(){
	std::cout<<"Welcome to the program"<<std::endl;
}
int main(){
	printWelcome();
	printWelcome();
	printWelcome();
			
}
