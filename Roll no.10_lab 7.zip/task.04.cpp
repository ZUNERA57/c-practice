#include<iostream>
using namespace std;
bool isEven(int num){
	return num%2==0;
}
int main(){
	int number = 6;
	if(isEven(number)) {
		std::cout<<number<<"is even"<<std::endl;
	}
	else{
	
		std::cout<<number<<"is odd"<<std::endl;
	}
}
