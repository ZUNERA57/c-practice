#include<iostream>
using namespace std;
bool isPrime(int num){
	if(num<=1) return false;
	for(int i=2;i*i<=num;i++){
		if(num %i==0) return false;
	}
	return true;
}
int main(){
	int num1=4;
	int num2=67;
	cout<<num1<<"is prime "<<(isPrime(num1) ? "true" : "false") <<endl;
	cout<<num2<<"is prime"<<(isPrime(num2) ? "true" : "false")<<endl;
}
