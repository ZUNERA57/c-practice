#include<iostream>
using namespace std;
double celciusToFarenheit(double celcius){
	return (celcius * 9/5.0) + 32;
}
int main(){
	double celcius = 30;
	cout<<celcius<<"c is "<<celciusToFarenheit(celcius)<<"F"<<endl;
}
