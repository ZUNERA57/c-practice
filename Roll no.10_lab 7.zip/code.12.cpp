#include<iostream>
#include<cmath>
using namespace std;
double circleArea(double r){
	return M_PI * r*r;
}
int main(){
	double radii[]= {1.0,2.5,9.7,0.6};
	for(int i=0;i<5;i++){
		std::cout<<"Area of circle with radius"<<radii[i]<<": "<<circleArea(radii[i])<<std::endl;
	}
}
