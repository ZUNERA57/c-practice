#include<iostream>
#include<cmath>
using namespace std;
double calculateRingArea(double ro, double ri){
	return M_PI * (pow(ro,2)- pow(ri,2));
}
int main(){
	double outerRadius = 9.0;
	double innerRadius = 2.6;
	double area = calculateRingArea(outerRadius, innerRadius);
	std::cout<<"The area of the ring = "<<area<<std::endl;
}


