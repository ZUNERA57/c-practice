#include<iostream>
using namespace std;
int largest(int a, int b, int c){
	if(a>=b && a>=c)
	return a;
	else if(b>=a && b>=c)
	return b;
	else
	return c;
}
int main(){
	int num1 = 10,num2=90,num3=6;
	std::cout<<"Largest value is = "<<largest(num1,num2,num3);
}
