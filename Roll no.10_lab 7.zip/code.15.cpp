#include<iostream>
using namespace std;
void menu(){
	cout<<"Menu = "<<endl;
	cout<<"1. Option 1"<<endl;
	cout<<"2. Option 2"<<endl;
	cout<<"3. Option 3"<<endl;
}
int main(){
	menu();
	int choice;
	cout<<"Enter your choice = ";
	cin>>choice;
	cout<<"U choose = "<<choice<<endl;
}
